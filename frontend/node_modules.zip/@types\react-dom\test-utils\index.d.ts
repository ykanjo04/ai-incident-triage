export {};

export {
    /**
     * @deprecated Import `act` from `react` instead.
     */ act,
} from "react";
